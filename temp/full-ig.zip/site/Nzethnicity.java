package http://hl7.org.nz/fhir/ImplementationGuide/nz-base;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class Nzethnicity {

}
